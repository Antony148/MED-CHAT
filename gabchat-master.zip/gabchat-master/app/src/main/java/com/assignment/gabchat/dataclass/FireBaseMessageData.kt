package com.assignment.gabchat.dataclass

data class FireBaseMessageData(var SenderUserName: String?= null, var ReciverUserName: String?= null, var Message:String?= null){

}
