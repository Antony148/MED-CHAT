package com.assignment.gabchat.dataclass

data class UserDetails(var userName: String?= null, var phoneNumber: String?= null, var password: String?= null) {
}