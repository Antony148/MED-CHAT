package com.assignment.gabchat.dataclass

data class ChannelModel(var userName: String, var nickName: String, var channelUrl:String) {
}

