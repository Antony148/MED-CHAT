package com.assignment.gabchat.Interface

import com.assignment.gabchat.dataclass.ChannelModel

interface AddContactClickedListener {
    fun onAddContactListener(channel: ChannelModel)
}