package com.assignment.gabchat.ConstantValues

object SendBirdConstantValues {
     val EXTRA_CHANNEL_URL = "EXTRA_CHANNEL_URL"
     val CHANNEL_HANDLER_ID = "CHANNEL_HANDLER_GROUP_CHANNEL_CHAT"
     val USER_MESSAGE = 10
     val USER_MESSAGE_OTHER = 11
}


